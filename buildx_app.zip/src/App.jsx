import { useState } from "react";
import "./styles/todo.css";

function App() {
const [tasks, setTasks] = useState([]);
const [taskText, setTaskText] = useState("");

const addTask = () => {
    if (!taskText.trim()) return;

    setTasks([
    ...tasks,
    {
        id: Date.now(),
        title: taskText,
        completed: false,
    },
    ]);

    setTaskText("");
};

const toggleTask = (id) => {
    setTasks(
    tasks.map((task) =>
        task.id === id
        ? { ...task, completed: !task.completed }
        : task
    )
    );
};

return (
    <main className="app">
    <section className="card">
        <h1>BuildX Todo App</h1>
        <p>Create and manage your daily tasks.</p>

        <div className="task-form">
        <input
            value={taskText}
            onChange={(event) => setTaskText(event.target.value)}
            placeholder="Enter a task"
        />
        <button onClick={addTask}>Add Task</button>
        </div>

        <ul className="task-list">
        {tasks.map((task) => (
            <li key={task.id}>
            <label>
                <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTask(task.id)}
                />
                <span className={task.completed ? "done" : ""}>
                {task.title}
                </span>
            </label>
            </li>
        ))}
        </ul>
    </section>
    </main>
);
}

export default App;
